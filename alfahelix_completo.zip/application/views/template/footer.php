<footer>
	<div class="container text-center">
		<p>Alfahelix by <a href="http://diegomariano.com"><span>Diego Mariano</span></a> | Template by <a href="http://moozthemes.com"><span>MOOZ</span>Themes.com</a></p>
	</div>
</footer>
